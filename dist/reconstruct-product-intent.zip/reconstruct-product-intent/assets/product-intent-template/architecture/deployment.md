```mermaid
flowchart TB
  %% ARCH-* environments, deployment topology, network and trust zones.
```
