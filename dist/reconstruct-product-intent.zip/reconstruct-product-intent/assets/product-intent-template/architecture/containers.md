```mermaid
flowchart TB
  %% ARCH-* deployable containers/services and data stores.
```
