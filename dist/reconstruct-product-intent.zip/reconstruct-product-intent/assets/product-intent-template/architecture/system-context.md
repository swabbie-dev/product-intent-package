```mermaid
flowchart LR
  %% ARCH-* system context and trust boundaries.
```
